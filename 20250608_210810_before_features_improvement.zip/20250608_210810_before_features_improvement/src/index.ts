import notificationsRouter from "./routes/notifications";

// Add routes
app.use("/api/notifications", notificationsRouter); 