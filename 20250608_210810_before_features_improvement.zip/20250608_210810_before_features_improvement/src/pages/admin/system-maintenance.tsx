import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Database, Trash2, FileX, Download, HardDrive, Activity } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import Breadcrumb from "@/components/breadcrumb";

export default function SystemMaintenance() {
  const { toast } = useToast();

  const { data: audioFiles } = useQuery({
    queryKey: ["/api/admin/audio-files"],
  });

  const { data: systemMetrics } = useQuery({
    queryKey: ["/api/admin/system-metrics"],
  });

  // Calculate storage usage
  const totalStorageUsed = (audioFiles as any[])?.reduce((acc: number, file: any) => acc + file.fileSize, 0) || 0;
  const storageUsageGB = totalStorageUsed / (1024 * 1024 * 1024);
  const storageLimit = 10; // GB
  const storagePercentage = (storageUsageGB / storageLimit) * 100;

  const handleCleanupCache = () => {
    if (confirm('Bạn có chắc muốn xóa tất cả file cache? Thao tác này không thể hoàn tác.')) {
      // Implementation would go here
      toast({
        title: "Thành công",
        description: "Cache hệ thống đã được dọn dẹp",
      });
    }
  };

  const handleCleanupTempFiles = () => {
    if (confirm('Bạn có chắc muốn xóa các file tạm thời? Thao tác này không thể hoàn tác.')) {
      // Implementation would go here
      toast({
        title: "Thành công",
        description: "File tạm thời đã được xóa",
      });
    }
  };

  const handleBackupData = () => {
    // Implementation would go here
    toast({
      title: "Thành công",
      description: "Đang tạo bản sao lưu dữ liệu",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        <Breadcrumb 
          title="Bảo trì hệ thống" 
          showBackButton={true} 
          backUrl="/admin"
        />
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Storage Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <HardDrive className="h-5 w-5 text-red-600" />
                Quản lý dung lượng
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              
              {/* Storage Overview */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span>Dung lượng đã sử dụng:</span>
                  <span className="font-medium">
                    {storageUsageGB.toFixed(2)} GB / {storageLimit} GB
                  </span>
                </div>
                <Progress value={storagePercentage} className="h-2" />
                <p className="text-xs text-gray-500">
                  {storagePercentage.toFixed(1)}% dung lượng đã được sử dụng
                </p>
              </div>

              {/* Storage Details */}
              <div className="space-y-3">
                <h4 className="font-medium">Chi tiết dung lượng</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Audio files:</span>
                    <span>{(totalStorageUsed / (1024 * 1024)).toFixed(1)} MB</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cache files:</span>
                    <span>245 MB</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Temp files:</span>
                    <span>89 MB</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Database:</span>
                    <span>156 MB</span>
                  </div>
                </div>
              </div>

              {/* Cleanup Actions */}
              <div className="space-y-3">
                <h4 className="font-medium">Dọn dẹp dữ liệu</h4>
                <div className="space-y-2">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={handleCleanupCache}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Dọn dẹp cache hệ thống
                  </Button>

                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={handleCleanupTempFiles}
                  >
                    <FileX className="h-4 w-4 mr-2" />
                    Xóa file tạm thời
                  </Button>

                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={handleBackupData}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Sao lưu dữ liệu
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* System Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-green-600" />
                Hiệu suất hệ thống
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              
              {/* Performance Metrics */}
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>CPU Usage</span>
                    <span>45%</span>
                  </div>
                  <Progress value={45} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Memory (RAM)</span>
                    <span>62%</span>
                  </div>
                  <Progress value={62} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Network I/O</span>
                    <span>28%</span>
                  </div>
                  <Progress value={28} className="h-2" />
                </div>
              </div>

              {/* Service Status */}
              <div className="space-y-3">
                <h4 className="font-medium">Trạng thái dịch vụ</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Web Server</span>
                    <Badge variant="default">Hoạt động</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Database</span>
                    <Badge variant="default">Hoạt động</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">OpenAI API</span>
                    <Badge variant="default">Hoạt động</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Email Service</span>
                    <Badge variant="secondary">Bảo trì</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">File Storage</span>
                    <Badge variant="default">Hoạt động</Badge>
                  </div>
                </div>
              </div>

              {/* System Info */}
              <div className="space-y-3">
                <h4 className="font-medium">Thông tin hệ thống</h4>
                <div className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                  <div className="flex justify-between">
                    <span>Uptime:</span>
                    <span>7 ngày 14 giờ</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Users:</span>
                    <span>1,247</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Audio Files:</span>
                    <span>{(audioFiles as any[])?.length || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Last Backup:</span>
                    <span>2 giờ trước</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

        </div>

        {/* Maintenance Schedule */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5 text-blue-600" />
              Lịch bảo trì
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Bảo trì hàng ngày</h4>
                  <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <li>• Dọn dẹp log files</li>
                    <li>• Kiểm tra dung lượng</li>
                    <li>• Monitor performance</li>
                  </ul>
                  <p className="text-xs text-green-600 mt-2">Tự động vào 2:00 AM</p>
                </div>

                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Bảo trì hàng tuần</h4>
                  <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <li>• Backup database</li>
                    <li>• Update security patches</li>
                    <li>• Optimize database</li>
                  </ul>
                  <p className="text-xs text-blue-600 mt-2">Chủ nhật, 1:00 AM</p>
                </div>

                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Bảo trì hàng tháng</h4>
                  <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <li>• Full system backup</li>
                    <li>• Performance analysis</li>
                    <li>• Security audit</li>
                  </ul>
                  <p className="text-xs text-purple-600 mt-2">Ngày 1 hàng tháng</p>
                </div>

              </div>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}