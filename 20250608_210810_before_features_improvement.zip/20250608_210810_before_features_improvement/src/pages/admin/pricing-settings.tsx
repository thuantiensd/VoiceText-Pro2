import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAdminFormState } from "@/hooks/useAdminFormState";
import AdminConfirmDialog from "@/components/admin-confirm-dialog";
import { DollarSign, Package, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Breadcrumb from "@/components/breadcrumb";
import type { UpdatePaymentSettings, PaymentSettings } from "@shared/schema";

export default function PricingSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: paymentSettings, isLoading } = useQuery({
    queryKey: ["/api/payment-settings"],
  });

  const updateSettings = useMutation({
    mutationFn: async (data: UpdatePaymentSettings) => {
      return await apiRequest("PUT", "/api/payment-settings", data);
    },
    onSuccess: () => {
      toast({
        title: "Thành công",
        description: "Bảng giá dịch vụ đã được cập nhật",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/payment-settings"] });
      formState.resetFormState();
    },
    onError: (error: Error) => {
      toast({
        title: "Lỗi",
        description: error.message,
        variant: "destructive",
      });
      formState.setIsSubmitting(false);
    },
  });

  const formState = useAdminFormState<UpdatePaymentSettings>({
    initialData: paymentSettings as PaymentSettings,
    onSave: (data) => updateSettings.mutate(data),
  });

  const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data: UpdatePaymentSettings = {
      proMonthlyPrice: Number(formData.get("proMonthlyPrice")),
      proYearlyPrice: Number(formData.get("proYearlyPrice")),
      premiumMonthlyPrice: Number(formData.get("premiumMonthlyPrice")),
      premiumYearlyPrice: Number(formData.get("premiumYearlyPrice")),
    };
    formState.handleSubmit(data);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const calculateYearlyDiscount = (monthly: number, yearly: number) => {
    const monthlyTotal = monthly * 12;
    const discount = ((monthlyTotal - yearly) / monthlyTotal) * 100;
    return Math.round(discount);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <Breadcrumb 
          title="Bảng giá dịch vụ" 
          showBackButton={true} 
          backUrl="/admin"
        />
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-green-600" />
              Quản lý bảng giá dịch vụ
            </CardTitle>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Cấu hình giá cho các gói dịch vụ Pro và Premium
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleFormSubmit} className="space-y-6">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Pro Plan */}
                <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950/20">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-300">
                      <Package className="h-5 w-5" />
                      Gói Pro
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="proMonthlyPrice">Giá hàng tháng (VND)</Label>
                      <Input
                        id="proMonthlyPrice"
                        name="proMonthlyPrice"
                        type="number"
                        defaultValue={paymentSettings?.proMonthlyPrice || 99000}
                        onChange={formState.handleInputChange}
                        placeholder="99000"
                        min="0"
                        step="1000"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="proYearlyPrice">Giá hàng năm (VND)</Label>
                      <Input
                        id="proYearlyPrice"
                        name="proYearlyPrice"
                        type="number"
                        defaultValue={paymentSettings?.proYearlyPrice || 990000}
                        onChange={formState.handleInputChange}
                        placeholder="990000"
                        min="0"
                        step="1000"
                      />
                    </div>

                    {paymentSettings?.proMonthlyPrice && paymentSettings?.proYearlyPrice && (
                      <div className="p-3 bg-green-100 dark:bg-green-900/20 rounded-lg">
                        <div className="flex items-center gap-2 text-green-700 dark:text-green-300">
                          <TrendingUp className="h-4 w-4" />
                          <span className="font-medium">
                            Tiết kiệm {calculateYearlyDiscount(paymentSettings.proMonthlyPrice, paymentSettings.proYearlyPrice)}% khi đăng ký theo năm
                          </span>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Premium Plan */}
                <Card className="border-purple-200 bg-purple-50 dark:bg-purple-950/20">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-purple-700 dark:text-purple-300">
                      <Package className="h-5 w-5" />
                      Gói Premium
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="premiumMonthlyPrice">Giá hàng tháng (VND)</Label>
                      <Input
                        id="premiumMonthlyPrice"
                        name="premiumMonthlyPrice"
                        type="number"
                        defaultValue={paymentSettings?.premiumMonthlyPrice || 199000}
                        onChange={formState.handleInputChange}
                        placeholder="199000"
                        min="0"
                        step="1000"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="premiumYearlyPrice">Giá hàng năm (VND)</Label>
                      <Input
                        id="premiumYearlyPrice"
                        name="premiumYearlyPrice"
                        type="number"
                        defaultValue={paymentSettings?.premiumYearlyPrice || 1990000}
                        onChange={formState.handleInputChange}
                        placeholder="1990000"
                        min="0"
                        step="1000"
                      />
                    </div>

                    {paymentSettings?.premiumMonthlyPrice && paymentSettings?.premiumYearlyPrice && (
                      <div className="p-3 bg-green-100 dark:bg-green-900/20 rounded-lg">
                        <div className="flex items-center gap-2 text-green-700 dark:text-green-300">
                          <TrendingUp className="h-4 w-4" />
                          <span className="font-medium">
                            Tiết kiệm {calculateYearlyDiscount(paymentSettings.premiumMonthlyPrice, paymentSettings.premiumYearlyPrice)}% khi đăng ký theo năm
                          </span>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Pricing Guidelines */}
              <Card className="bg-gray-50 dark:bg-gray-800">
                <CardHeader>
                  <CardTitle className="text-lg">Hướng dẫn định giá</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium text-blue-700 dark:text-blue-300">Gói Pro</h4>
                      <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1 mt-2">
                        <li>• Dành cho cá nhân và doanh nghiệp nhỏ</li>
                        <li>• Tối đa 100 file audio/tháng</li>
                        <li>• Tối đa 10,000 ký tự/tháng</li>
                        <li>• Truy cập tất cả giọng đọc</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium text-purple-700 dark:text-purple-300">Gói Premium</h4>
                      <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1 mt-2">
                        <li>• Dành cho doanh nghiệp và chuyên gia</li>
                        <li>• Tối đa 1,000 file audio/tháng</li>
                        <li>• Tối đa 50,000 ký tự/tháng</li>
                        <li>• Tất cả tính năng nâng cao</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Save Button */}
              <div className="flex gap-4 pt-6 border-t">
                {formState.hasChanges && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={formState.handleReset}
                  >
                    Hủy thay đổi
                  </Button>
                )}
                <Button 
                  type="submit" 
                  disabled={formState.isSubmitting || !formState.hasChanges}
                  className="bg-green-600 hover:bg-green-700 disabled:opacity-50"
                >
                  {formState.isSubmitting ? "Đang lưu..." : "Lưu bảng giá"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>

      <AdminConfirmDialog
        open={formState.showConfirmDialog}
        onOpenChange={formState.setShowConfirmDialog}
        onConfirm={formState.handleConfirmSave}
        title="Xác nhận lưu thay đổi"
        description="Bạn có chắc chắn muốn cập nhật bảng giá dịch vụ? Thay đổi này sẽ ảnh hưởng đến tất cả người dùng mới."
      />
    </div>
  );
}